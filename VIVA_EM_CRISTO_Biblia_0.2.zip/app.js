const API="https://api.getbible.net/v2/livre.json";
const APP_VERSION="0.2.0";
const state={data:null,bookIndex:0,chapter:1,font:19,favorites:new Set(JSON.parse(localStorage.getItem("vivaFavorites")||"[]")),dark:localStorage.getItem("vivaDark")==="1"};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const escapeHtml=s=>String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2200)}
function save(){localStorage.setItem("vivaFavorites",JSON.stringify([...state.favorites]));}
function setView(id){$$(".view").forEach(v=>v.classList.toggle("active",v.id===id));$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.nav===id));window.scrollTo({top:0,behavior:"smooth"});if(id==="favoritesView")renderFavorites()}
function key(book,chapter,verse){return `${book}|${chapter}|${verse}`}
function books(){return state.data?.books||[]}
function currentBook(){return books()[state.bookIndex]}
function chapters(book){return book?.chapters||[]}
function currentChapter(){return chapters(currentBook()).find(c=>Number(c.chapter)===Number(state.chapter))}
function normalizeData(raw){return raw && raw.books ? raw : null}
async function loadBible(){
  try{
    const cached=localStorage.getItem("vivaBibleCache");
    if(cached) {
      try { state.data=normalizeData(JSON.parse(cached)); } catch(_) { localStorage.removeItem("vivaBibleCache"); }
    }
    if(!state.data){
      const r=await fetch(API,{headers:{"Accept":"application/json"}});
      if(!r.ok) throw new Error("Falha na fonte bíblica");
      state.data=normalizeData(await r.json());
      localStorage.setItem("vivaBibleCache",JSON.stringify(state.data));
    }
    if(!state.data) throw new Error("Formato não reconhecido");
    populateSelectors(); renderDaily(); renderChapter();
  }catch(e){
    $("#dailyVerse").innerHTML=`<p><b>Não foi possível carregar a Bíblia agora.</b></p><p class="muted">Verifique a internet e tente novamente.</p>`;
    $("#chapterText").innerHTML=`<p class="muted">A fonte bíblica não respondeu. O aplicativo continua instalado e poderá tentar novamente quando houver conexão.</p>`;
  }
}
function populateSelectors(){
  const bs=$("#bookSelect");bs.innerHTML=books().map((b,i)=>`<option value="${i}">${escapeHtml(b.book_name||b.name)}</option>`).join("");
  bs.value=state.bookIndex;
  fillChapters();
}
function fillChapters(){
  const cs=$("#chapterSelect"), ch=chapters(currentBook());
  cs.innerHTML=ch.map(c=>`<option value="${c.chapter}">${c.chapter}</option>`).join("");
  cs.value=state.chapter;
}
function verseArray(ch){return ch?.verses||[]}
function verseText(v){return v.text||v.verse_text||v.texto||v.literal_pt||""}
function renderChapter(){
  const b=currentBook(), ch=currentChapter(); if(!b||!ch)return;
  $("#readingTitle").textContent=`${b.book_name||b.name} ${ch.chapter}`;
  $("#chapterText").innerHTML=`<h3>${escapeHtml(b.book_name||b.name)} ${ch.chapter}</h3>`+
    verseArray(ch).map(v=>{const k=key(b.book_short||b.book_name||b.name,ch.chapter,v.verse);const fav=state.favorites.has(k);return `<div class="verse ${fav?"favorite":""}" data-k="${escapeHtml(k)}"><button class="verse-star" title="Favoritar" onclick="toggleFavorite('${k.replaceAll("'","\\'")}')">${fav?"★":"☆"}</button><span class="verse-num">${v.verse}</span>${escapeHtml(verseText(v))}</div>`}).join("");
  $("#chapterText").style.setProperty("--font-size",state.font+"px");
}
window.toggleFavorite=k=>{state.favorites.has(k)?state.favorites.delete(k):state.favorites.add(k);save();renderChapter();toast(state.favorites.has(k)?"Versículo salvo.":"Removido dos favoritos.")};
function renderFavorites(){
  const el=$("#favoritesList"), arr=[...state.favorites];
  if(!arr.length){el.innerHTML=`<div class="result"><b>Nenhum favorito ainda.</b><p class="muted">Durante a leitura, toque na estrela de um versículo para guardá-lo.</p></div>`;return}
  el.innerHTML="";
  arr.forEach(k=>{const [short,chap,ver]=k.split("|");const b=books().find(x=>(x.book_short||x.book_name||x.name)===short);const c=chapters(b).find(x=>Number(x.chapter)===Number(chap));const v=verseArray(c).find(x=>Number(x.verse)===Number(ver));if(!b||!v)return;const div=document.createElement("div");div.className="result";div.innerHTML=`<b>${escapeHtml(b.book_name||b.name)} ${chap}:${ver}</b><p>${escapeHtml(verseText(v))}</p><button class="mini-btn">Abrir capítulo</button> <button class="mini-btn" onclick="toggleFavorite('${k.replaceAll("'","\\'")}')">Remover</button>`;div.querySelector("button").onclick=()=>{state.bookIndex=books().indexOf(b);state.chapter=Number(chap);populateSelectors();setView("bibleView");renderChapter()};el.appendChild(div)})
}
function renderDaily(){
  const all=[];books().forEach((b,bi)=>chapters(b).forEach(c=>verseArray(c).forEach(v=>all.push({b,c,v,bi}))));
  if(!all.length)return;
  const startOfYear=new Date(new Date().getFullYear(),0,0);
  const day=Math.floor((new Date()-startOfYear)/86400000);
  const idx=day%all.length, x=all[idx], ref=`${x.b.book_name||x.b.name} ${x.c.chapter}:${x.v.verse}`;
  $("#todayDate").textContent=new Date().toLocaleDateString("pt-BR",{day:"2-digit",month:"long"});
  $("#dailyVerse").innerHTML=`<blockquote>“${escapeHtml(verseText(x.v))}”</blockquote><div class="verse-ref">${escapeHtml(ref)}</div><div class="verse-actions"><button class="mini-btn" onclick="copyVerse('${ref.replaceAll("'","\\'")}','${escapeHtml(verseText(x.v)).replaceAll("'","\\'")}')">Copiar</button><button class="mini-btn" onclick="shareVerse('${ref.replaceAll("'","\\'")}','${escapeHtml(verseText(x.v)).replaceAll("'","\\'")}')">Compartilhar</button><button class="mini-btn" onclick="openRef(${x.bi},${x.c.chapter})">Ler capítulo</button></div>`;
}
window.openRef=(bi,ch)=>{state.bookIndex=bi;state.chapter=Number(ch);populateSelectors();setView("bibleView");renderChapter()};
window.copyVerse=async(ref,text)=>{await navigator.clipboard?.writeText(`“${text}”\n\n${ref}\nVIVA EM CRISTO`);toast("Versículo copiado.")};
window.shareVerse=async(ref,text)=>{const msg=`“${text}”\n\n${ref}\n\nVIVA EM CRISTO\nPermaneça na Palavra.`;if(navigator.share){await navigator.share({title:"VIVA EM CRISTO",text:msg})}else{await navigator.clipboard?.writeText(msg);toast("Texto copiado para compartilhar.")}}
async function searchBible(){
  const q=$("#searchInput").value.trim().toLowerCase();const out=$("#searchResults");
  if(q.length<2){out.innerHTML="";$("#searchStatus").textContent="Digite pelo menos 2 caracteres.";return}
  if(!state.data){return}
  const results=[];for(let bi=0;bi<books().length&&results.length<80;bi++){const b=books()[bi];for(const c of chapters(b)){for(const v of verseArray(c)){if(verseText(v).toLowerCase().includes(q)){results.push({bi,b,c,v});if(results.length>=80)break}}if(results.length>=80)break}}
  $("#searchStatus").textContent=`${results.length}${results.length===80?"+":""} resultado(s).`;
  out.innerHTML=results.length?results.map(x=>`<div class="result"><b>${escapeHtml(x.b.book_name||x.b.name)} ${x.c.chapter}:${x.v.verse}</b><p>${highlight(escapeHtml(verseText(x.v)),q)}</p><button class="mini-btn" onclick="openRef(${x.bi},${x.c.chapter})">Abrir capítulo</button></div>`).join(""):`<div class="result">Nenhum resultado encontrado.</div>`;
}
function highlight(t,q){const safe=q.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return t.replace(new RegExp(safe,"ig"),m=>`<mark>${m}</mark>`)}
function adjustFont(delta){state.font=Math.max(16,Math.min(25,state.font+delta));document.documentElement.style.setProperty("--font-size",state.font+"px");$("#fontRange").value=state.font;renderChapter()}
function toggleDark(){state.dark=!state.dark;document.body.classList.toggle("dark",state.dark);localStorage.setItem("vivaDark",state.dark?"1":"0")}
$("#themeBtn").onclick=toggleDark;$("#darkToggle").onclick=toggleDark;$("#openBibleBtn").onclick=()=>setView("bibleView");$("#backHome").onclick=()=>setView("homeView");
$("#bookSelect").onchange=e=>{state.bookIndex=Number(e.target.value);state.chapter=1;fillChapters();renderChapter()};
$("#chapterSelect").onchange=e=>{state.chapter=Number(e.target.value);renderChapter()};
$("#prevChapter").onclick=$("#prevChapter2").onclick=()=>moveChapter(-1);$("#nextChapter").onclick=$("#nextChapter2").onclick=()=>moveChapter(1);
function moveChapter(d){const ch=chapters(currentBook());let i=ch.findIndex(x=>Number(x.chapter)===Number(state.chapter))+d;if(i<0){if(state.bookIndex>0){state.bookIndex--;state.chapter=chapters(currentBook()).length;populateSelectors()}else return}else if(i>=ch.length){if(state.bookIndex<books().length-1){state.bookIndex++;state.chapter=1;populateSelectors()}else return}else state.chapter=Number(ch[i].chapter);renderChapter()}
$("#fontDown").onclick=$("#setFontDown").onclick=()=>adjustFont(-1);$("#fontUp").onclick=$("#setFontUp").onclick=()=>adjustFont(1);$("#fontRange").oninput=e=>{state.font=Number(e.target.value);renderChapter()};
$("#searchBtn").onclick=searchBible;$("#searchInput").onkeydown=e=>{if(e.key==="Enter")searchBible()};
$("#clearData").onclick=()=>{state.favorites.clear();save();renderFavorites();toast("Favoritos removidos.")};
$$(".nav-item").forEach(b=>b.onclick=()=>setView(b.dataset.nav));$$(".quick-card").forEach(b=>b.onclick=()=>setView(({bible:"bibleView",favorites:"favoritesView",search:"searchView",settings:"settingsView"})[b.dataset.action]));
if(state.dark)document.body.classList.add("dark");document.documentElement.style.setProperty("--font-size",state.font+"px");$("#fontRange").value=state.font;
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js"));
loadBible();

$("#menuBtn").onclick=()=>{toast("Use a barra inferior para navegar pelo app.");};
document.addEventListener("visibilitychange",()=>{if(!document.hidden)loadBible();});
