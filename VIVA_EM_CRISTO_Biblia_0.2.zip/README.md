# VIVA EM CRISTO — Bíblia 0.2

## Objetivo
MVP/PWA visualmente refinado para a primeira validação do projeto VIVA EM CRISTO.

## O que mudou na 0.2
- Identidade visual mais sofisticada e consistente.
- Home com hero, chamada espiritual e áreas futuras.
- Navegação mobile mais limpa.
- Leitura com controles de fonte e capítulos.
- Favoritos e busca mantidos.
- Persistência local.
- Modo escuro.
- PWA preparada para instalação.
- Fallback por cache do conteúdo bíblico já carregado.
- Versículo do dia com seleção determinística por dia do ano.

## Fonte bíblica
A implementação usa Bíblia Livre (BLIVRE), distribuída pela API pública getBible.
A BLIVRE é licenciada com atribuição; mantenha os créditos exigidos pela licença. Consulte o projeto BLIVRE antes de distribuir uma cópia ou adaptar o texto.

## Teste local
Sirva a pasta por HTTPS ou HTTP local:
python -m http.server 8080

Abra:
http://localhost:8080

## Próximo ciclo
- testar em Android real;
- revisar acessibilidade;
- melhorar ícones e splash;
- adicionar Devocional;
- adicionar Oração;
- adicionar Plano de Leitura;
- criar deep links para WhatsApp;
- depois avaliar empacotamento Android.
